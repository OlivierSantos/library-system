package DataAccess;

import java.util.HashMap;
import java.util.Map;

public class DataAccessImpl<K, V> implements DataAccess<K, V> {
	private Map<K, V> dataMap = new HashMap<K, V>();

	@Override
	public V create(K key, V value) {
		return dataMap.put(key, value);
	}
	@Override
	public V read(K key) {
		return dataMap.get(key);
	}
	@Override
	public V update(K key, V value) {
		return dataMap.put(key, value);
	}

	@Override
	public V delete(K key) {
		return dataMap.remove(key);	
	}
	
	
}
