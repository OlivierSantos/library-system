package AccessRights;

import Checkout.CheckoutRecord;

//import java.util.Set;

import DataAccess.DataAccess;
import DataAccess.DataAccessImpl;

public class LibraryMemberController {
	private static LibraryMemberController instance = new LibraryMemberController();

	private DataAccess<Integer, LibraryMember> dataAccess = new DataAccessImpl<Integer, LibraryMember>();

	private LibraryMemberController() {

	}

	public static LibraryMemberController getInstance() {
		return instance;
	}

	public LibraryMember addNewMember(LibraryMember member) {
		return dataAccess.create(member.getMemberID(), member);
	}

	public LibraryMember getMemberById(int id) {
		return dataAccess.read(id);
	}

	public LibraryMember editMember(LibraryMember member) {
		return dataAccess.update(member.getMemberID(), member);
	}

	public LibraryMember deleteMember(int id) {
		return dataAccess.delete(id);
	}

}
