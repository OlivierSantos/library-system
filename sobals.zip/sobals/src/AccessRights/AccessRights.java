package AccessRights;

public abstract class AccessRights {
	private final boolean allowedAddNewMember;
	private final boolean allowedEditExistMember;
	private final boolean allowedAddNewBook;
	private final boolean allowedAddCopytoExistBook;
	private final boolean allowedCheckoutBook;
	private final boolean allowedPrintCheckoutRecord;
	private final boolean allowedSearchBook;
	
	public AccessRights(boolean allowedAddNewMember, boolean allowedEditExistMember, boolean allowedAddNewBook,
			boolean allowedAddCopytoExistBook, boolean allowedCheckoutBook, boolean allowedPrintCheckoutRecord,
			boolean allowedSearchBook) {
		super();
		this.allowedAddNewMember = allowedAddNewMember;
		this.allowedEditExistMember = allowedEditExistMember;
		this.allowedAddNewBook = allowedAddNewBook;
		this.allowedAddCopytoExistBook = allowedAddCopytoExistBook;
		this.allowedCheckoutBook = allowedCheckoutBook;
		this.allowedPrintCheckoutRecord = allowedPrintCheckoutRecord;
		this.allowedSearchBook = allowedSearchBook;
	}
	public abstract boolean addNewMember();
	public abstract boolean editExistMember();
	public abstract boolean addNewBook();
	public abstract boolean addCopytoExistBook();
	public abstract boolean checkoutBook();
	public abstract boolean printCheckoutRecord();
	public boolean searchBook() {
		return true;
	}
	public boolean isAllowedAddNewMember() {
		return allowedAddNewMember;
	}
	public boolean isAllowedEditExistMember() {
		return allowedEditExistMember;
	}
	public boolean isAllowedAddNewBook() {
		return allowedAddNewBook;
	}
	public boolean isAllowedAddCopytoExistBook() {
		return allowedAddCopytoExistBook;
	}
	public boolean isAllowedCheckoutBook() {
		return allowedCheckoutBook;
	}
	public boolean isAllowedPrintCheckoutRecord() {
		return allowedPrintCheckoutRecord;
	}
	public boolean isAllowedSearchBook() {
		return allowedSearchBook;
	}
	
	
}
