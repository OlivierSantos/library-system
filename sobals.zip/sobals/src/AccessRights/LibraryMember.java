package AccessRights;

import Checkout.CheckoutController;
import Checkout.CheckoutEntry;
import Checkout.CheckoutRecord;
import Person.*;

public class LibraryMember extends AccessRights {
	private int memberId;
	private CheckoutRecord cor;
	private Person person;

	public LibraryMember(int id) {
		super(false, false, false, false, false, false, true);
		this.memberId = id;
		this.cor = new CheckoutRecord(this);
	}

	public int getMemberID() {
		return this.memberId;
	}

	@Override
	public boolean addNewMember() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean editExistMember() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean addNewBook() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean addCopytoExistBook() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean checkoutBook() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean printCheckoutRecord() {
		// TODO Auto-generated method stub
		return false;
	}

	public CheckoutRecord getCheckoutRecord() {
		return this.cor;
	}

	public void addCheckoutEntry(CheckoutEntry coe) {
		this.cor.addCheckoutEntry(coe);
	}

	public Person getPerson() {
		return person;
	}

	public void setPerson(Person person) {
		this.person = person;
	}

}
