package AccessRights;

public class Administrator extends AccessRights {

	public Administrator() {
		super(true, true, true, true, false,false, true);
	}
	@Override
	public boolean addNewMember() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean editExistMember() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean addNewBook() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean addCopytoExistBook() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean printCheckoutRecord() {
		// TODO Auto-generated method stub
		return false;
	}
	@Override
	public boolean checkoutBook() {
		// TODO Auto-generated method stub
		return false;
	}

}
