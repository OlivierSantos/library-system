package AccessRights;

public class Librarian extends AccessRights {

	public Librarian() {
		super(false, false, false, false, true, true, true);
	}
	@Override
	public boolean addNewMember() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean editExistMember() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean addNewBook() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean addCopytoExistBook() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean checkoutBook() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean printCheckoutRecord() {
		// TODO Auto-generated method stub
		return false;
	}

}
