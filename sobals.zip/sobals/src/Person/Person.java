package Person;

import java.util.List;

import java.util.ArrayList;

public class Person {
	private List<Address> addresses;
	private String firstName;
	private String lastName;
	public Person() {
		super();
		addresses = new ArrayList<>();
	}
	public Person(String firstName, String lastName) {
		this();
		this.firstName = firstName;
		this.lastName = lastName;
	}
	
	public Person(String firstName, String lastName, List<Address> addresses) {
		super();
		this.addresses = addresses;
		this.firstName = firstName;
		this.lastName = lastName;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public List<Address> getAddresses() {
		return addresses;
	}
	
}
