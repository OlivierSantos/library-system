package admin.controller;



public class AdminController {
	
	
	public int editBook(int bookId) {
		return bookId;
		
	}

}
