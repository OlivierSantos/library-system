package admin.model;

public class Admin extends UserRole{

}
