package admin.model;

public class UserRole {
	

}
