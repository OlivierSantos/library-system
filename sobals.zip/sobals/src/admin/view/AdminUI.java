package admin.view;

import java.io.IOException;

import admin.model.Admin;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class AdminUI extends Application{
	private static Stage primaryStage;
	private static BorderPane bordPane;
	private static Stage editStage;
	private static Stage addStage;
	
	
	public static void main(String[] args) {
		launch(args);
	}
	
//	public AdminUI(Stage aStage, Stage eStage) throws IOException {
//		addStage=aStage;
//		editStage=eStage;
//		
//		
//		
//	}

	@Override
	public void start(Stage ps) throws Exception {
		this.primaryStage=ps;
		this.primaryStage.setTitle("Admin Panel");
		showAdminPanel();
//		Parent root=FXMLLoader.load(getClass().getResource("Admin/AdminMain.fxml"));
//		System.out.println("I am done");
//		Scene scene=new Scene(root);
//		primaryStage.setScene(scene);
//		primaryStage.show();
	}

private void showAdminPanel() throws IOException {
	FXMLLoader loader=new FXMLLoader();
	           loader.setLocation(AdminUI.class.getResource("AdminMain.fxml"));
     bordPane=loader.load();
     Scene scene=new Scene(bordPane);
     primaryStage.setScene(scene);
     primaryStage.show();
}

public static void showCheckOutBook() throws IOException {
	FXMLLoader loader=new FXMLLoader();
    loader.setLocation(AdminUI.class.getResource("EditBook.fxml"));
    BorderPane bookItems=loader.load();
    bordPane.setCenter(bookItems);
     
}

public static void showAddBookUI() throws IOException {
	FXMLLoader loader=new FXMLLoader();
	loader.setLocation(AdminUI.class.getResource("AddBook.fxml"));
    BorderPane addBook=loader.load();
    //bordPane.setCenter(addBook);
    addStage=new Stage();
    addStage.setTitle("Add Book");
    addStage.initModality(Modality.WINDOW_MODAL);
    addStage.initOwner(primaryStage);
    Scene scene=new Scene(addBook);
    
    addStage.setScene(scene);
    addStage.show();
    
}   

public static void showEditBookUI() throws IOException {
	FXMLLoader loader=new FXMLLoader();
	loader.setLocation(AdminUI.class.getResource("EditBook.fxml"));
	BorderPane editBook=loader.load();
	
	//add new stage
	
	System.out.println("Screen On other side");
	
	editStage=new Stage();
	editStage.setTitle("Edit New Book");
	editStage.initModality(Modality.WINDOW_MODAL);
	editStage.initOwner(primaryStage);
	Scene scene=new Scene(editBook);
	editStage.setScene(scene);
	editStage.show();
	
	
}

public void showMessage() throws IOException {
	FXMLLoader loader=new FXMLLoader();
	loader.setLocation(AdminUI.class.getResource("Message.fxml"));
	BorderPane messageBook=loader.load();
	
	//add new stage
	
	
	Stage addMessageStage=new Stage();
	addMessageStage.setTitle("Notification");
	addMessageStage.initModality(Modality.WINDOW_MODAL);
	addMessageStage.initOwner(addStage);
	Scene scene=new Scene(messageBook);
	addMessageStage.setScene(scene);
	addMessageStage.show();
	
}



}
