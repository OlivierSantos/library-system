package admin.view;

import java.io.IOException;

import javafx.fxml.FXML;

public class AdminMainUIController {
	private AdminUI adminUI;
	
	@FXML
	
	public void getHome() throws IOException {
		
	}

}
