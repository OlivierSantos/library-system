package admin.view;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import Author.Author;
import Book.Book;
import Book.BookController;
import Book.BookCopy;
import DataAccess.DataAccess;
import Person.Address;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

public class BookUIController {
	ObservableList<String> maxDays= FXCollections.observableArrayList("21","7");
	List<Author> authors=new ArrayList<Author>();
	ObservableList<String> authorsDisp= FXCollections.observableArrayList("Olivier","Elyse","Claude","Tom","Christophe");
	private AdminUI adminUI;
	@FXML
	private TextField bookName;
	@FXML
	private TextField searchSerial;
	@FXML
	private TextField serialNumber;
	@FXML
	private TextField title;
	@FXML
	private TextField description;
	@FXML
	private ChoiceBox<String> author;
	@FXML
	private TextField numberCopies;
	@FXML
	private ChoiceBox<String> maxCheckoutDays;
	@FXML
	private DatePicker dateEdited;
	
	@FXML 
	
	private Label errorMessage;
	@FXML
	private void initialize() 
	{   maxCheckoutDays.setValue("21");
		maxCheckoutDays.setItems(maxDays);
		author.setValue("Olivier");
		author.setItems(authorsDisp);
		
	}
	
	
	@FXML
	public void getBooKinformation() {
     try {
    	 BookController books=BookController.getInstance();
		 if(searchSerial!=null||searchSerial.getText()!="") {
			 
			 if(books.getBookByISBN(searchSerial.getText())!=null) {
			
		     bookName.setText(books.getBookByISBN(searchSerial.getText()).getBookName());
		     title.setText(books.getBookByISBN(searchSerial.getText()).getTitle());
		     description.setText(books.getBookByISBN(searchSerial.getText()).getDescription());
		     dateEdited.setValue(books.getBookByISBN(searchSerial.getText()).getDateCreated());
		     author.setValue(books.getBookByISBN(searchSerial.getText()).getAuthorName());
		     numberCopies.setText(Integer.toString(books.getBookByISBN(searchSerial.getText()).getNumberOfCopies()));
		     maxCheckoutDays.setValue(Integer.toString(books.getBookByISBN(searchSerial.getText()).getMaxCheckoutDays()));
		     serialNumber.setText(searchSerial.getText());
		
		 }
		 else {
			 bookName.setText("");
		     title.setText("");
		     description.setText("");
		     numberCopies.setText("");
		     serialNumber.setText("");
		

			 errorMessage.setText("Serial Number does not exists");
			 
		 } 
		 }
			 else{
				 errorMessage.setText("Fill the Serial Number first");
			 }
    	 
     }catch(Exception e) {
    	 System.out.println(e.getMessage());
     }
		
	}
	@FXML
	public void addBook() throws IOException {
		
		 try{
			  
		if(serialNumber!=null||serialNumber.getText()!=""&&title!=null||title.getText()!=""||
		numberCopies.getText()!=null ||numberCopies.getText()!="") {
		
		 BookController books=BookController.getInstance();	
		 Author auth=new Author(author.getValue());
		 List<Author> authors=new ArrayList<Author>();
		 authors.add(auth);
		 Book book=new Book();	
		 
		 if(books.getBookByISBN(serialNumber.getText())==null) {
		 //book.setMaxCheckoutDays((int)maxCheckoutDays.getValue());
		 book.setAuthorName(author.getValue().toString());
		 book.setNumberOfCopies(Integer.parseInt(numberCopies.getText()));
		 book.setBookName(bookName.getText());
		 book.setIsbn(serialNumber.getText());
		 book.setDateCreated(dateEdited.getValue());
		 book.setTitle(title.getText());
		 book.setAuthors(authors);
		 
		 books.addABook(book);
		 
		 for(int i=0; i<authors.size();i++) {
			 System.out.println(authors.get(i).getFirstName());
		 }
		 
		 
		 for(int i=0; i<Integer.parseInt(numberCopies.getText()); i++) {
				 BookCopy bookCopy=new BookCopy(book);
				 bookCopy.setBookCopyStatus(false);
				 bookCopy.setBookId(i+"_"+serialNumber.getText());
				 bookCopy.setCopyNumber(i);
			    books.addACopy(book);
				 }
		    System.out.println(author.toString());
			System.out.println(books.getBookByISBN(serialNumber.getText()).getBookName());
			
			errorMessage.setText("Serial Number:"+serialNumber.getText()+"Added");
			resetInput();
		
			
			 
		 }
		 else {
			 errorMessage.setText("Sorry, Adding book failed");
			 resetInput();
		 }
		}
		else {
			 errorMessage.setText("Sorry, Book Exists");
			 resetInput();
		}
		
		
		 }catch(Exception e) {
			 System.out.println(e.getMessage());
		 }
		
	}
	


	@FXML
	public void editBook() throws IOException {
		
		
		 
		try {
			
			 	
		if(serialNumber!=null||serialNumber.getText()!=""&&title!=null||title.getText()!=""||
				numberCopies!=null ||numberCopies.getText()!="") {
		 
			BookController books=BookController.getInstance();
			Book book=new Book();	
			
			if(books==null) {
				errorMessage.setText("No Data");
				
			}
		
	
		 book.setAuthorName(author.getValue().toString());
		 book.setNumberOfCopies(Integer.parseInt(numberCopies.getText()));
		 book.setBookName(bookName.getText());
		 book.setIsbn(serialNumber.getText());
		 book.setDateCreated(dateEdited.getValue());
		 book.setTitle(title.getText());
		 
		 if(books.editBook(book)==true) {
			 
			 System.out.println("Serial Number:"+books.getBookByISBN(serialNumber.getText()).getIsbn());
			 System.out.println("Book Name:"+books.getBookByISBN(serialNumber.getText()).getBookName());
			 System.out.println("Author Name:"+books.getBookByISBN(serialNumber.getText()).getAuthorName());
			 
			 errorMessage.setText("It was successfully Edited");
			 resetInput();
		 }
		 else {
			
			 errorMessage.setText("Sorry, Editing book failed");
			 resetInput();
		 }
		 
		
		
		 
		}
		else {
			 errorMessage.setText("Some input field are empy");
		}
		
		}
		catch(Exception e) {
			System.out.println(e.getMessage());
			
		}
		
		
	}
	
	public void resetInput() {
		   serialNumber.setText("");
		   title.setText("");
		   bookName.setText("");
		   description.setText("");
		   numberCopies.setText("");
		   
	}
	
	
	
	
	

}
