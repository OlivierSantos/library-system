package admin.view;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import Author.Author;
import Book.Book;
import Book.BookController;
import Book.BookCopy;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

public class AdminUIController {
	
	private AdminUI adminUI;
	
	ObservableList<String> maxDays= FXCollections.observableArrayList("21","7");
	List<Author> authors=new ArrayList<Author>();
	ObservableList<String> authorsDisp= FXCollections.observableArrayList("Olivier","Elyse");
	@FXML
	private TextField bookName;
	@FXML
	private TextField serialNumber;
	@FXML
	private TextField title;
	@FXML
	private TextField description;
	@FXML
	private ChoiceBox<String> author;
	@FXML
	private TextField numberCopies;
	@FXML
	private ChoiceBox<String> maxCheckoutDays;
	@FXML
	private DatePicker dateEdited;
	
	@FXML 
	private Label errorMessage;

	@FXML
	private void initializeAuthor() {
		
	}
	
	@FXML
	public void getAddBookUI() throws IOException {
		AdminUI.showAddBookUI();
	}
	
	@FXML
	public void getEditBookUI() throws IOException {
		AdminUI.showEditBookUI();
	}
	@FXML
	public void getBookItems() throws IOException {
		AdminUI.showCheckOutBook();
	}
	
	
	
	
	
	
}
