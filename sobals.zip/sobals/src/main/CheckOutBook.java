package main;

import AccessRights.LibraryMember;
import AccessRights.LibraryMemberController;
import Book.Book;
import Book.BookController;
import Checkout.CheckoutController;
import Person.Address;
import Person.Person;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class CheckOutBook {
	public CheckOutBook() {
	}

	public static void checkoutbook(String title) {
		Stage window = new Stage();
		MessageBox mbox = new MessageBox();

		window.initModality(Modality.APPLICATION_MODAL);
		window.setTitle(title);
		window.setMinWidth(200);

		GridPane grid = new GridPane();
		grid.setAlignment(Pos.CENTER);
		grid.setHgap(20);
		grid.setVgap(20);
		grid.setPadding(new Insets(25, 25, 25, 25));

		Label lbook_isbn = new Label("Book ISBN: ");
		grid.add(lbook_isbn, 0, 0);

		TextField tbook_isbn = new TextField();
		grid.add(tbook_isbn, 1, 0);

		Label lmem_id = new Label("Library member ID: ");
		grid.add(lmem_id, 0, 1);

		TextField tmem_id = new TextField();
		grid.add(tmem_id, 1, 1);

		Button checkoutbook = new Button("Check");
		grid.add(checkoutbook, 1, 6);

		checkoutbook.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent e) {

				String ret = checkValidation(tbook_isbn.getText(), tmem_id.getText());

				if (!ret.equalsIgnoreCase("")) {
					mbox.display("Notification", ret);
				} else {
					CheckoutController coc = CheckoutController.getInstance();
					String result = coc.checkoutBook(tbook_isbn.getText(), tmem_id.getText());
					System.out.println(result);
					mbox.display("The below checkout is successfully done:", result);
				}

			}

		});

		Scene scene = new Scene(grid, 500, 400);
		window.setScene(scene);

		window.showAndWait();

	}

	public static String checkValidation(String book, String mem) {
		String ret = "";

		if (book.length() == 0)
			ret += "Enter Book ISBN\n";
		else if (!isInteger(book))
			ret += "Enter a valid ISBN\n";
		if (mem.equalsIgnoreCase(""))
			ret += "Enter Member ID\n";
		return ret;
	}

	public static boolean isInteger(String s) {
		try {
			Integer.parseInt(s);
		} catch (NumberFormatException e) {
			return false;
		} catch (NullPointerException e) {
			return false;
		}
		// only got here if we didn't return false
		return true;
	}
}
