package main;

import java.util.ArrayList;
import java.util.List;

import AccessRights.*;
import Person.*;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class AddLibMember {

	public AddLibMember() {
		
	}

	public static void addLibMember(String title) {
		Stage window = new Stage();
		MessageBox mbox = new MessageBox();

		window.initModality(Modality.APPLICATION_MODAL);
		window.setTitle(title);
		window.setMinWidth(200);

		GridPane grid = new GridPane();
		grid.setAlignment(Pos.CENTER);
		grid.setHgap(20);
		grid.setVgap(20);
		grid.setPadding(new Insets(25, 25, 25, 25));

		Label memberidL = new Label("New MemberID: ");
		grid.add(memberidL, 0, 0);
		
		TextField memberF = new TextField();
		grid.add(memberF, 1, 0);
		
		Label fnameL = new Label("First Name: ");
		grid.add(fnameL, 0, 1);

		TextField fnameF = new TextField();
		grid.add(fnameF, 1, 1);

		Label lnameL = new Label("Last Name: ");
		grid.add(lnameL, 0, 2);

		TextField lnameF = new TextField();
		grid.add(lnameF, 1, 2);

		Label streetL = new Label("Street: ");
		grid.add(streetL, 0, 3);

		TextField streetF = new TextField();
		grid.add(streetF, 1, 3);

		Label cityL = new Label("City: ");
		grid.add(cityL, 0, 4);

		TextField cityF = new TextField();
		grid.add(cityF, 1, 4);

		Label zipcodeL = new Label("ZipCode: ");
		grid.add(zipcodeL, 0, 5);

		TextField zipcodeF = new TextField();
		grid.add(zipcodeF, 1, 5);

		Label telephoneL = new Label("Telephone: ");
		grid.add(telephoneL, 0, 6);

		TextField telephoneF = new TextField();
		grid.add(telephoneF, 1, 6);

		Button save = new Button("Save");
		grid.add(save, 1, 7);

		save.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent e) {
				String memid = memberF.getText();
				String ret = isValidation(memberF.getText(), fnameF.getText(), lnameF.getText(), streetF.getText(), cityF.getText(),
						zipcodeF.getText(), telephoneF.getText());

				if (!ret.equalsIgnoreCase("")) {
					mbox.display("Notifocation", ret);
				} else {
					LibraryMemberController controller = LibraryMemberController.getInstance();

					if(controller.getMemberById( Integer.parseInt(memid) ) == null)
					{
						Address address = new Address(streetF.getText(), cityF.getText(), Address.State.IOWA, zipcodeL.getText(), telephoneF.getText());
						List<Address> addresses = new ArrayList<>();
						addresses.add(address);
						Person person = new Person(fnameF.getText(), lnameF.getText(), addresses);
						
						//Person person = new Person(fnameF.getText(), lnameF.getText());
						//Address address = new Address(person, streetF.getText(), cityF.getText(), Address.ZipCode.IOWA, telephoneF.getText());
						LibraryMember libmem = new LibraryMember( Integer.parseInt(memid) );
						libmem.setPerson(person);
						controller.addNewMember(libmem);
						
						System.out.println(person.toString());
						mbox.display("Added", person.toString());
						System.out.println(controller.getMemberById(libmem.getMemberID()));
					}
					else
						mbox.display("Notifocation", memid + " - This member already created in here");
				}

			}
		});

		Scene scene = new Scene(grid, 500, 450);
		window.setScene(scene);

		window.showAndWait();

	}

	public static String isValidation(String memberF, String fnameF, String lnameF, String streetF, String cityF, String zipcodeF, String telephoneF) {
		String ret = "";

		if (memberF.length() == 0)
			ret += "New MemberID is required. \n";
		
		if (fnameF.length() == 0)
			ret += "First name is required. \n";

		if (streetF.equalsIgnoreCase(""))
			ret += "Street is required. \n";

		if (telephoneF.equalsIgnoreCase(""))
			ret += "Telephone number is required. ";

		return ret;
	}
}
