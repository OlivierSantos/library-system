package main;

import Checkout.CheckoutController;
import java.util.ArrayList;

import AccessRights.LibraryMember;
import AccessRights.LibraryMemberController;
import Book.Book;
import Book.BookController;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;
import javafx.scene.layout.VBox;

public class Main extends Application {

	public static void main(String[] args) {

		// launch(args);

		// create Admin
		// create Librarian
		// Admin creates LibMember(s)
		// Librarian checkouts book

		CheckoutController coc = CheckoutController.getInstance();
		BookController bc = BookController.getInstance();
		LibraryMemberController lmc = LibraryMemberController.getInstance();

		Book book = new Book("title", "isbn", 21, "firstName", "lastName");
		LibraryMember lm = new LibraryMember(7);

		bc.addACopy(book);
		bc.addABook(book);
		lmc.addNewMember(lm);

		String s = coc.checkoutBook(book.getIsbn(), Integer.toString(lm.getMemberID()));
		// String ss =
		// coc.checkoutBook(book.getIsbn(),Integer.toString(lm.getMemberID()));

		printf(s);
		// printf(ss);

	}

	@Override
	public void start(Stage primaryStage) throws Exception {

		primaryStage.setTitle("SOBA - Library System - Demo");
		VBox imageHolder = new VBox();

		GridPane grid = new GridPane();
		grid.setAlignment(Pos.CENTER);
		grid.setHgap(20);
		grid.setVgap(20);
		grid.setPadding(new Insets(25, 25, 25, 25));

		// Image image = new Image("main/library.jpg", 400, 300, false, false);
		// ImageView iv = new ImageView();
		// iv.setImage(image);
		// imageHolder.getChildren().add(iv);
		// imageHolder.setAlignment(Pos.CENTER);

		Button newmem = new Button("Add new Member");
		grid.add(newmem, 0, 0);

		Button editmem = new Button("Edit Member");
		grid.add(editmem, 0, 1);

		Button newBook = new Button("Add new Book");
		grid.add(newBook, 0, 2);

		Button addbook = new Button("Add Book Copy");
		grid.add(addbook, 0, 3);

		Button checkout = new Button("Checkout Book");
		grid.add(checkout, 0, 4);

		Button print = new Button("Print");
		grid.add(print, 0, 5);

		Button searchISBN = new Button("Search by ISBN");
		grid.add(searchISBN, 0, 6);

		Label input = new Label("Input");
		grid.add(input, 1, 0);

		TextField inputTextField = new TextField();
		grid.add(inputTextField, 1, 1);

		Label output = new Label("Output");
		grid.add(output, 1, 2);

		TextField outputTextField = new TextField();
		grid.add(outputTextField, 1, 3);

		HBox hbBtn = new HBox(10);
		hbBtn.setAlignment(Pos.CENTER_RIGHT);

		grid.add(hbBtn, 1, 3);

		Scene scene = new Scene(grid, 500, 400);
		primaryStage.setScene(scene);
		scene.getStylesheets().add(getClass().getResource("SOBA_LibSystem.css").toExternalForm());
		primaryStage.show();

		newmem.setOnAction(e -> AddLibMember.addLibMember("Add new Member"));
		checkout.setOnAction(e -> CheckOutBook.checkoutbook("Check out book"));
	}

	private static <T> void printf(T value) {
		System.out.println(value);
	}

}
