package main;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import static javafx.geometry.HPos.RIGHT;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.PasswordField;
import javafx.scene.control.SeparatorMenuItem;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCombination;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import javafx.stage.Stage;

public class MainWindow extends Application {

	@Override
	public void start(Stage primaryStage) throws Exception {
		// TODO Auto-generated method stub
		primaryStage.setTitle("SOBA Library System");
		VBox topContainer = new VBox();
		Scene scene = new Scene(topContainer, 400, 350);
		scene.setFill(Color.OLDLACE);

		MenuBar menuBar = new MenuBar();

		// --- Menu File
		Menu menuFile = new Menu("File");

		// --- Menu Admin
		Menu menuAdmin = new Menu("Admin");
		menuAdmin.setVisible(false);

		// --- Menu Librarian
		Menu menuLibrarian = new Menu("Librarian");
		menuLibrarian.setVisible(false);

		// --- Menu Library Member
		Menu menuMember = new Menu("Member");
		menuMember.setVisible(false);

		// Login menu
		MenuItem login = new MenuItem("Login");
		login.setOnAction((e) -> {
			GridPane loginGrid = new GridPane();
			loginGrid.setAlignment(Pos.CENTER);
			loginGrid.setHgap(10);
			loginGrid.setVgap(10);
			loginGrid.setPadding(new Insets(25, 25, 25, 25));

			Text scenetitle = new Text("Welcome");
			// setting id for CSS styling
			// scenetitle.setId("welcome-text");
			loginGrid.add(scenetitle, 0, 0, 2, 1);

			Label userId = new Label("User ID: ");
			loginGrid.add(userId, 0, 1);

			TextField userTextField = new TextField();
			loginGrid.add(userTextField, 1, 1);

			Label pw = new Label("Password: ");
			loginGrid.add(pw, 0, 2);

			PasswordField pwBox = new PasswordField();
			loginGrid.add(pwBox, 1, 2);

			Button btn = new Button("Login");
			HBox hbBtn = new HBox(10);
			hbBtn.setAlignment(Pos.BOTTOM_RIGHT);
			hbBtn.getChildren().add(btn);
			loginGrid.add(hbBtn, 1, 4);
			btn.setOnAction((t) -> {
				switch (userTextField.getText()) {
				// Admin
				case "A":
					menuAdmin.setVisible(true);
					login.setDisable(true);
					loginGrid.setVisible(false);
					final VBox vbox = new VBox();
					vbox.setAlignment(Pos.TOP_LEFT);
					vbox.setSpacing(10);
					vbox.setPadding(new Insets(0, 10, 0, 10));
					// final ImageView pic = new ImageView();
					// pic.setImage(new Image("library.jpg"));
					final Label name = new Label();
					name.setText("Ok ok");
					final Label binName = new Label();
					binName.setText("SOK");
					final Label description = new Label();
					description.setText("I come from ...");
					vbox.getChildren().addAll(name, binName, description);
					topContainer.getChildren().add(vbox);
					break;
				// Librarian
				case "L":
					menuLibrarian.setVisible(true);
					login.setDisable(true);
					break;
				// Library Member
				case "M":
					menuMember.setVisible(true);
					login.setDisable(true);
					break;
				// Admin & Librarian
				case "AL":
					menuAdmin.setVisible(true);
					menuLibrarian.setVisible(true);
					login.setDisable(true);
					break;

				default:
					break;
				}

			});
			// final Text actiontarget = new Text();
			// grid.add(actiontarget, 1, 6);
			// setting id for CSS styling
			// actiontarget.setId("actiontarget");

			// scene.getStylesheets().add(getClass().getResource("Login.css").toExternalForm());
			topContainer.getChildren().add(loginGrid);
			loginGrid.setVisible(true);
		});
		// Exit menu
		MenuItem exit = new MenuItem("Exit");
		exit.setAccelerator(KeyCombination.keyCombination("Ctrl+X"));
		exit.setOnAction((e) -> {
			System.exit(0);
		});

		// Add New Member menu
		MenuItem addMember = new MenuItem("Add a new Member");
		addMember.setAccelerator(KeyCombination.keyCombination("Ctrl+M"));

		// newmem.setOnAction(
		// e -> AddLibMember.addLibMember("Add new Member")
		// );

		addMember.setOnAction(e -> AddLibMember.addLibMember("Add new Member"));

		// Edit Member menu
		MenuItem editMember = new MenuItem("Edit an existing Member");
		editMember.setAccelerator(KeyCombination.keyCombination("Ctrl+E"));
		editMember.setOnAction(e -> EditLibMember.EditLibMember("Edit Member"));
		// Add Book menu
		MenuItem addBook = new MenuItem("Add a new Book");
		addBook.setAccelerator(KeyCombination.keyCombination("Ctrl+B"));
		addBook.setOnAction((e) -> {
			// TODO
		});
		// Add Book Copy menu
		MenuItem addBookCopy = new MenuItem("Add Copy to an existing Book");
		addBookCopy.setAccelerator(KeyCombination.keyCombination("Ctrl+C"));
		addBookCopy.setOnAction((e) -> {
			// TODO
		});
		// Checkout Book menu
		MenuItem checkoutBook = new MenuItem("Checkout a Book");
		checkoutBook.setAccelerator(KeyCombination.keyCombination("Ctrl+O"));
		checkoutBook.setOnAction((e) -> {
			CheckOutBook.checkoutbook("Check out book");
		});
		// Print menu
		MenuItem print = new MenuItem("Print Checkout record to Console");
		print.setAccelerator(KeyCombination.keyCombination("Ctrl+P"));
		print.setOnAction((e) -> {
			// TODO
		});
		// Search menu
		MenuItem search = new MenuItem("Search Book");
		search.setAccelerator(KeyCombination.keyCombination("Ctrl+S"));
		search.setOnAction((e) -> {
			// TODO
		});

		menuFile.getItems().addAll(login, new SeparatorMenuItem(), exit);
		menuAdmin.getItems().addAll(addMember, editMember, new SeparatorMenuItem(), addBook, addBookCopy);
		menuLibrarian.getItems().addAll(checkoutBook, print, search);
		menuMember.getItems().addAll(search);

		menuBar.getMenus().addAll(menuFile, menuAdmin, menuLibrarian, menuMember);

		topContainer.getChildren().addAll(menuBar);

		primaryStage.setScene(scene);
		primaryStage.show();

	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		launch(args);
	}

}
