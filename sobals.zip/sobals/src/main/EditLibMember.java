package main;

import java.util.ArrayList;
import java.util.List;

import AccessRights.*;
import Person.*;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class EditLibMember {

	public EditLibMember() {
		
	}

	public static void EditLibMember(String title) {
		Stage window = new Stage();
		MessageBox mbox = new MessageBox();

		window.initModality(Modality.APPLICATION_MODAL);
		window.setTitle(title);
		window.setMinWidth(200);

		GridPane grid = new GridPane();
		grid.setAlignment(Pos.CENTER);
		grid.setHgap(20);
		grid.setVgap(20);
		grid.setPadding(new Insets(25, 25, 25, 25));

		Label memberidL = new Label("MemberID: ");
		grid.add(memberidL, 0, 0);

		TextField memberidF = new TextField();
		grid.add(memberidF, 1, 0);
		
		Button selectbtn = new Button("Select");
		grid.add(selectbtn, 1, 1);
		
		
		
		Label fnameL = new Label("First Name: ");
		grid.add(fnameL, 0, 2);

		TextField fnameF = new TextField();
		grid.add(fnameF, 1, 2);

		Label lnameL = new Label("Last Name: ");
		grid.add(lnameL, 0, 3);

		TextField lnameF = new TextField();
		grid.add(lnameF, 1, 3);

		Label streetL = new Label("Street: ");
		grid.add(streetL, 0, 4);

		TextField streetF = new TextField();
		grid.add(streetF, 1, 4);

		Label cityL = new Label("City: ");
		grid.add(cityL, 0, 5);

		TextField cityF = new TextField();
		grid.add(cityF, 1, 5);

		Label zipcodeL = new Label("ZipCode: ");
		grid.add(zipcodeL, 0, 6);

		TextField zipcodeF = new TextField();
		grid.add(zipcodeF, 1, 6);

		Label telephoneL = new Label("Telephone: ");
		grid.add(telephoneL, 0, 7);

		TextField telephoneF = new TextField();
		grid.add(telephoneF, 1, 7);

		Button save = new Button("Save");
		grid.add(save, 1, 8);

		selectbtn.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent e) {
				String memid = memberidF.getText();
				String ret = isValidation( memid );

				if (!ret.equalsIgnoreCase("")) {
					mbox.display("Notifocation", ret);
				} else {
					LibraryMemberController controller = LibraryMemberController.getInstance();
					LibraryMember libmem;
					libmem = controller.getMemberById(Integer.parseInt(memid));
					
					if(libmem == null)
						mbox.display("Notifocation", memid + " - This member is not here");
					else
					{
						Person person = libmem.getPerson();
						fnameF.setText(person.getFirstName());
						lnameF.setText(person.getLastName());
						
						List<Address> addresses = person.getAddresses();
						//addresses.get(0).getStreet();
						
						streetF.setText(addresses.get(0).getStreet());
						cityF.setText(addresses.get(0).getCity());
						//Address.State.IOWA;
						//zipcodeL.setText(addresses.get(0).getZip());
						
						telephoneF.setText(addresses.get(0).getTelephone());
					}
				}

			}
		});
		
		save.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent e) {

				String ret = isValidation(fnameF.getText(), lnameF.getText(), streetF.getText(), cityF.getText(),
						zipcodeF.getText(), telephoneF.getText());

				if (!ret.equalsIgnoreCase("")) {
					mbox.display("Notifocation", ret);
				} else {
					LibraryMemberController controller = LibraryMemberController.getInstance();
					
					Address address = new Address(streetF.getText(), cityF.getText(), Address.State.IOWA, zipcodeL.getText(), telephoneF.getText());
					List<Address> addresses = new ArrayList<>();
					addresses.add(address);
					Person person = new Person(fnameF.getText(), lnameF.getText(), addresses);
					
					
					
					//Person person = new Person(fnameF.getText(), lnameF.getText());
					//Address address = new Address(person, streetF.getText(), cityF.getText(), Address.ZipCode.IOWA, telephoneF.getText());
					
					LibraryMember libmem = new LibraryMember( Integer.parseInt(memberidF.getText()) );
					libmem.setPerson(person);
					controller.editMember( libmem);
					
					System.out.println(person.toString());
					mbox.display("Edited", person.toString());
					System.out.println(controller.getMemberById(libmem.getMemberID()));
					
				}

			}
		});

		Scene scene = new Scene(grid, 500, 450);
		window.setScene(scene);

		window.showAndWait();

	}

	public static String isValidation(String fnameF, String lnameF, String streetF, String cityF, String zipcodeF, String telephoneF) {
		String ret = "";

		if (fnameF.length() == 0)
			ret += "First name is required. \\n";

		if (streetF.equalsIgnoreCase(""))
			ret += "Street is required. \\n";

		if (telephoneF.equalsIgnoreCase(""))
			ret += "Telephone number is required. ";

		return ret;
	}
	
	public static String isValidation(String memberidF) {
		String ret = "";

		if (memberidF.length() == 0)
			ret += "Member ID is required. \\n";

		return ret;
	}
}
