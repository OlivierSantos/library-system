package main;

import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class MessageBox {
	public MessageBox() {
		//
	}

	public void display(String title, String message) {

		Stage winm = new Stage();
		winm.setTitle(title);
		winm.setMinWidth(300);
		winm.initModality(Modality.APPLICATION_MODAL);

		Label label = new Label();
		label.setText(message);

		Button closebtn = new Button("Close");
		closebtn.setOnAction(e -> winm.close());

		VBox layout = new VBox(10);
		layout.getChildren().addAll(label, closebtn);
		layout.setAlignment(Pos.CENTER);

		Scene scene = new Scene(layout);
		winm.setScene(scene);
		winm.showAndWait();

	}
}
