package Checkout;

import AccessRights.*;
import Book.Book;

import java.util.List;
import java.util.ArrayList;
import java.util.HashMap;

public class CheckoutRecord {
	private int LibMemID;
	private List<CheckoutEntry> checkoutEntries;

	public CheckoutRecord(LibraryMember lm) {
		this.LibMemID = lm.getMemberID();
		checkoutEntries = new ArrayList<>();
	}

	public String getID() {
		return Integer.toString(LibMemID) + "'s checkoutRecord";
	}

	public void addCheckoutEntry(CheckoutEntry coe) {
		this.checkoutEntries.add(coe);
	}

	public List<CheckoutEntry> getCheckoutEntries() {
		return checkoutEntries;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();

		for (CheckoutEntry coe : this.getCheckoutEntries()) {
			sb.append("--------------------------------------------\n");
			sb.append(coe.getCheckoutBook().toString() + " has checked out by Library Member " + this.LibMemID);
			sb.append(System.getProperty("line.separator"));
			sb.append("Check out Date: " + coe.getCheckoutDate());
			sb.append(System.getProperty("line.separator"));
			sb.append("Due Date:" + coe.getDueDate());
			sb.append(System.getProperty("line.separator"));
			sb.append("--------------------------------------------");
			sb.append(System.getProperty("line.separator"));
		}
		return sb.toString();
	}
}
