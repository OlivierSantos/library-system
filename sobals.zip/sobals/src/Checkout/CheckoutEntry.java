package Checkout;

import java.util.Date;
import Book.Book;
import Book.BookCopy;

public class CheckoutEntry {
	private BookCopy checkoutBook;
	private Date checkoutDate;
	private Date dueDate;

	public CheckoutEntry(BookCopy checkoutBook, Date checkoutDate, Date dueDate) {
		this.checkoutBook = checkoutBook;
		this.checkoutDate = checkoutDate;
		this.dueDate = dueDate;
	}

	public Date getCheckoutDate() {
		return checkoutDate;
	}

	public void setCheckoutDate(Date checkoutDate) {
		this.checkoutDate = checkoutDate;
	}

	public Date getDueDate() {
		return dueDate;
	}

	public void setDueDate(Date dueDate) {
		this.dueDate = dueDate;
	}

	public BookCopy getCheckoutBook() {
		return checkoutBook;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("---CHECK-OUT DETAILS---\n");
		sb.append(this.getCheckoutBook().toString());
		sb.append("Check out Date =  " + this.getCheckoutDate() + "\n");
		sb.append("Due Date = " + this.getDueDate() + "\n");
		sb.append("-----------------------\n");
		return sb.toString();
	}
}
