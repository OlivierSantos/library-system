package Checkout;

import java.util.Date;
import java.util.Calendar;

import AccessRights.LibraryMember;
import AccessRights.LibraryMemberController;
import Book.Book;
import Book.BookController;
import Book.BookCopy;
import DataAccess.DataAccess;
import DataAccess.DataAccessImpl;

public class CheckoutController {

    private static CheckoutController instance = new CheckoutController();

    private CheckoutController() {
    }

    public static CheckoutController getInstance() {
        return instance;
    }

    public String checkoutBook(String isbn, String libMemID) {
        String result = "";

        BookController bc = BookController.getInstance();
        LibraryMemberController lmc = LibraryMemberController.getInstance();

        Boolean doesBookExists = bc.bookExists(isbn);
        LibraryMember lm = lmc.getMemberById(Integer.parseInt(libMemID));
        Book book = null;
        System.out.println(isbn);
        if (lm == null) {
            result += "Library member not found\n";
        } else
            System.out.println("Library member with ID " + libMemID + " found\n");
        if (doesBookExists) {
            book = bc.getBookByISBN(isbn);
            BookCopy bookCopy = bc.getNextAvailableCopy(book);
            if (bookCopy == null) {
                result += new String("No available book copy found in the book with ISBN " + isbn + "\n");
                return result;
            }
            if (lm == null)
                return result;
            CheckoutEntry coe = checkoutBookHelper(lm, bookCopy, book);

            return coe.toString();
        } else {
            result += new String("There is no book with ISBN " + isbn);
            result += System.getProperty("line.separator");
        }
        return result;
    }

    private CheckoutEntry checkoutBookHelper(LibraryMember libmem, BookCopy bookCopy, Book book) {
        Date checkoutDate = new Date();
        Date dueDate = addDays(checkoutDate, book.getMaxCheckoutDays());
        CheckoutEntry coe = new CheckoutEntry(bookCopy, checkoutDate, dueDate);

        LibraryMemberController lmcontroller = LibraryMemberController.getInstance();
        libmem.addCheckoutEntry(coe);
        lmcontroller.editMember(libmem);

        BookController bc = BookController.getInstance();
        bookCopy.setBookCopyStatus(false);
        bc.updateBookCopy(bookCopy);
        return coe;
    }

    private Date addDays(Date date, int days) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        cal.add(Calendar.DATE, days); // minus number would decrement the days
        return cal.getTime();
    }

}