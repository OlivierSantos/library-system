package login;

public enum Authorization {
	LIBRARY_MEMBER, LIBRARIAN, ADMIN, LIBRARIAN_ADMIN
}
