package login;

public class Login {

	//to supress uninitialized warning, set it to null
	private final Authorization accessLevel;

	private int id;

	private String password;
	public Login(int id, Authorization accessLevel) {
		super();
		this.accessLevel = accessLevel;
		this.id = id;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public Authorization getAccessLevel() {
		return accessLevel;
	}
	public int getId() {
		return id;
	}
	
}
