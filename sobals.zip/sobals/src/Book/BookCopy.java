package Book;

public class BookCopy {
	private int copyNumber;
	private String bookId;// same as book ISBN
	private boolean bookCopyStatus;// Book status, availability

	public BookCopy(Book book) {
		this.copyNumber = book.getCopyNumber() + 1;
		this.bookId = book.getIsbn();
		this.bookCopyStatus = true;
	}

	public int getCopyNumber() {
		return copyNumber;
	}

	public void setCopyNumber(int copyNumber) {
		this.copyNumber = copyNumber;
	}

	public String getBookId() {
		return bookId;
	}

	public void setBookId(String bookId) {
		this.bookId = bookId;
	}

	public boolean getBookCopyStatus() {
		return bookCopyStatus;
	}

	public void setBookCopyStatus(boolean bookCopyStatus) {
		this.bookCopyStatus = bookCopyStatus;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("Book ID = " + this.bookId + "\n");
		sb.append("Book Copy ID = " + this.copyNumber + "\n");
		return sb.toString();
	}

}
