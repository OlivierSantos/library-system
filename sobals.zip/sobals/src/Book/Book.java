package Book;

import java.util.List;

import Author.Author;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;

public class Book {
	private String title;
	private String isbn;
	private List<Author> authors;
	private List<BookCopy> copies;
	private int maxCheckoutDays;
	private String description;
	private String bookName;
	private String authorName;
	private LocalDate dateCreated;
	private int numberOfCopies;
	public Book() {
		authors = new ArrayList<>();
		copies= new ArrayList<>();
		this.setIsbn(isbn);
	}

	public Book(String title, String isbn, int maxChesckoutDays, String firstName, String lastName) {
		authors = new ArrayList<>();
		this.setIsbn(isbn);
		// authors.add(new Author(authorName)));

	}

	public int getCopyNumber() {

		return this.numberOfCopies;

	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getIsbn() {
		return isbn;
	}

	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}

	public int getMaxCheckoutDays() {
		return maxCheckoutDays;
	}

	public void setMaxCheckoutDays(int maxCheckoutDays) {
		this.maxCheckoutDays = maxCheckoutDays;
	}

	public List<Author> getAuthors() {
		return authors;
	}

	public List<BookCopy> getCopies() {
		BookController bc = BookController.getInstance();

		return bc.getAllCopiesByBookID(this);
	}

	public boolean hasNextAvailableCopy() {
		boolean found = false;

		if (this.copies != null) {
			for (BookCopy bc : this.copies) {
				if (bc.getBookCopyStatus()) {
					found = true;
				}
			}
		}
		return found;
	}

	public List<BookCopy> addACopy() {
		BookCopy bc = new BookCopy(this);
		this.copies.add(bc);
		// this.copies = bc.getAllCopiesByBookID(this);
		return this.copies;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getBookName() {
		return bookName;
	}

	public void setBookName(String bookName) {
		this.bookName = bookName;
	}

	public String getAuthorName() {
		return authorName;
	}

	public void setAuthorName(String authorName) {
		this.authorName = authorName;
	}

	public LocalDate getDateCreated() {
		return dateCreated;
	}

	public void setDateCreated(LocalDate dateCreated) {
		this.dateCreated = dateCreated;
	}

	public int getNumberOfCopies() {
		return numberOfCopies;
	}

	public void setNumberOfCopies(int numberOfCopies) {
		this.numberOfCopies = numberOfCopies;
	}

	public void setAuthors(List<Author> authors) {
		this.authors = authors;
	}

	public void setCopies(List<BookCopy> copies) {
		this.copies = copies;
	}

	public boolean searchBookCopy() {
		boolean found = false;
		if (this.getCopies() != null) {
			for (BookCopy bc : this.copies) {
				if (bc.getBookCopyStatus()) {
					found = true;
				}
			}
		}
		return found;
	}

	public BookCopy getNextAvailableCopy() {
		boolean found = false;
		BookCopy result = null;
		if (this.getCopies() != null) {
			for (BookCopy bc : this.copies) {
				if (bc.getBookCopyStatus()) {
					found = true;
					return bc;
				}
			}
		}
		return result;
	}

	public void setBookCopyStatusUnAvailable(BookCopy bc1) {
		for (BookCopy bc : this.copies) {
			if (bc.getCopyNumber() == bc1.getCopyNumber() && bc.getBookId() == bc1.getBookId())
				bc.setBookCopyStatus(false);
		}
	}

}
