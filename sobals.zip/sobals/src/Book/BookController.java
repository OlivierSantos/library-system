package Book;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import AccessRights.AccessRights;
import Author.Author;
import DataAccess.DataAccess;
import DataAccess.DataAccessImpl;

public class BookController {
	private Book book;
	private BookCopy bookCopy;
	private DataAccess<String, Book> dataAccess = new DataAccessImpl<String, Book>();

	private static BookController instance = new BookController();
	private static DataAccess<String, List<BookCopy>> dataAccessBookCopy = new DataAccessImpl<String, List<BookCopy>>();

	public BookController() {

	}

	public static BookController getInstance() {
		return instance;
	}

	public boolean bookExists(String isbn) {
		return dataAccess.read(isbn)== null ? false : true;
	}

	private List<Book> getAllBook() {
		List<Book> books = new ArrayList<Book>();
		// implementation
		// books=dataAccess.read(")
		return books;
	}

	public void addABook(Book book) {
			dataAccess.create(book.getIsbn(), book);


	}


	public void updateBookCopy(BookCopy bookCopy) {
		List<BookCopy> list = dataAccessBookCopy.read(bookCopy.getBookId());
		for (BookCopy bc : list) {
			if (bc.getBookId().equals(bookCopy.getBookId()))
				bc = bookCopy;
		}
		dataAccessBookCopy.update(bookCopy.getBookId(), list);
	}

	public void addACopy(Book aCopy) {
		BookCopy bc = new BookCopy(aCopy);
		List<BookCopy> list = dataAccessBookCopy.read(aCopy.getIsbn());
		if (list == null) {
			list = new ArrayList<>();
			list.add(bc);
			dataAccessBookCopy.create(aCopy.getIsbn(), list);
		} else {
			list.add(bc);
			dataAccessBookCopy.update(aCopy.getIsbn(), list);
		}
		list = dataAccessBookCopy.read(aCopy.getIsbn());
		Arrays.toString(list.toArray());
	}

	public List<BookCopy> getAllCopiesByBookID(Book book) {
		List<BookCopy> list = dataAccessBookCopy.read(book.getIsbn());
		if (list == null)
			list = new ArrayList<BookCopy>();
		return list;
	}

	public boolean editBook(Book book) {
     if (book != null) {
			dataAccess.update(book.getIsbn(), book);

			return true;
		}
		return false;
	}

	public Book getBookByISBN(String ISBN) {
		return dataAccess.read(ISBN);
	}

	public BookCopy getNextAvailableCopy(Book book) {
		boolean found = false;
		BookCopy result = null;
		if (book.getCopies() != null) {
			for (BookCopy bc : book.getCopies()) {
				if (bc.getBookCopyStatus()) {
					found = true;
					result = bc;
					return bc;
				}
			}
		}
		return result;
	}
}
