package SystemUser;

import Person.Person;
import login.Login;
import AccessRights.*;

import java.util.List;
import java.util.ArrayList;

public class SystemUser extends Person {
	private Login login;
	private List<AccessRights> accessRights;
	public SystemUser(Login login) {
		super();
		this.login = login;
		accessRights = new ArrayList<>();
		switch(this.login.getAccessLevel()) {
			case LIBRARY_MEMBER:
				accessRights.add(new LibraryMember(login.getId()));
				break;
			case LIBRARIAN:
				accessRights.add(new Librarian());
				break;
			case ADMIN:
				accessRights.add(new Administrator());
				break;
			case LIBRARIAN_ADMIN:
				accessRights.add(new Librarian());
				accessRights.add(new Administrator());
				break;
		}
	}
}
