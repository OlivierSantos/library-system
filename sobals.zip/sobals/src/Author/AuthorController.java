package Author;

import java.util.ArrayList;
import java.util.List;

import DataAccess.DataAccess;

public class AuthorController {
	private List<Author> authors;
	private Author author;
	private DataAccess<String, Author> dataAccess; 
	
	public boolean authorExists(String firstName, String lastname) {
		List<Author> authors=getAllOther();
		for(Author a: authors) {
			if(firstName.compareTo(a.getFirstName())==0){
				return true;
			}
		}
	    
		return false;
	}

	private List<Author> getAllOther() {
		 List<Author> authors = new ArrayList<Author>();
		
		return authors;
	}
	
	private boolean addAuthor(Author author) {
		
		if(!authorExists(author.getFirstName(),author.getLastName())) {
			//Implement here with dataaccess
			dataAccess.create(author.getFirstName(), author);
		  }
		return false;
		
	}


	

}
