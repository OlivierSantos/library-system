package Author;

import Person.Person;

public class Author extends Person {
	private String cridentials;
	private String shortBio;
	public Author(String firstName, String lastName) {
		super(firstName, lastName);
	}
	public Author(String value) {
		
	}
	public String getCridentials() {
		return cridentials;
	}
	public void setCridentials(String cridentials) {
		this.cridentials = cridentials;
	}
	public String getShortBio() {
		return shortBio;
	}
	public void setShortBio(String shortBio) {
		this.shortBio = shortBio;
	}
	
}
